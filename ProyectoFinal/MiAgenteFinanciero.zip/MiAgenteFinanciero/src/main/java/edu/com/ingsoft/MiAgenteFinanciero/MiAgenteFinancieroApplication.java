package edu.com.ingsoft.MiAgenteFinanciero;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MiAgenteFinancieroApplication {

	public static void main(String[] args) {
		SpringApplication.run(MiAgenteFinancieroApplication.class, args);
	}

}
