package edu.com.ingsoft.MiAgenteFinanciero;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiAgenteFinancieroApplicationTests {

	@Test
	void contextLoads() {
	}

}
